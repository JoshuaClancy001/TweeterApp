"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserService = void 0;
const tweeter_shared_1 = require("tweeter-shared");
const buffer_1 = require("buffer");
class UserService {
    async login(alias, password) {
        // TODO: Replace with the result of calling the server
        const user = tweeter_shared_1.FakeData.instance.firstUser;
        if (user === null) {
            throw new Error("Invalid alias or password");
        }
        let userDto = user.dto;
        return [userDto, tweeter_shared_1.FakeData.instance.authToken.dto];
    }
    ;
    async register(firstName, lastName, alias, password, userImageBytes, imageFileExtension) {
        // Not neded now, but will be needed when you make the request to the server in milestone 3
        const imageStringBase64 = buffer_1.Buffer.from(userImageBytes).toString("base64");
        // TODO: Replace with the result of calling the server
        const user = tweeter_shared_1.FakeData.instance.firstUser;
        if (user === null) {
            throw new Error("Invalid registration");
        }
        return [user.dto, tweeter_shared_1.FakeData.instance.authToken.dto];
    }
    ;
    getUser = async (token, alias) => {
        let user = tweeter_shared_1.FakeData.instance.findUserByAlias(alias);
        return user?.dto || null;
    };
    async logout(token) {
        // ause so we can see the logging out message. Delete when the call to the server is implemented.
        await new Promise((res) => setTimeout(res, 1000));
    }
    ;
}
exports.UserService = UserService;
