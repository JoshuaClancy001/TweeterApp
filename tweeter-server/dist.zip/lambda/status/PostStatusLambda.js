"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const StatusServiceBase_1 = require("./StatusServiceBase");
const statusService = new StatusServiceBase_1.StatusServiceBase();
const handler = async (request) => {
    return await statusService.postStatus(request.token, request.status);
};
exports.handler = handler;
