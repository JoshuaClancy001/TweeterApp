"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserDynamoDao = void 0;
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
class UserDynamoDao {
    tableName = "Users";
    alias = "alias";
    password = "password";
    firstName = "first_name";
    lastName = "last_name";
    imageUrl = "image_url";
    client = lib_dynamodb_1.DynamoDBDocumentClient.from(new client_dynamodb_1.DynamoDBClient());
    async createUser(user, password) {
        const params = {
            TableName: this.tableName,
            Item: {
                [this.alias]: user.alias,
                [this.password]: password,
                [this.firstName]: user.firstName,
                [this.lastName]: user.lastName,
                [this.imageUrl]: user.imageUrl
            },
        };
        await this.client.send(new lib_dynamodb_1.PutCommand(params));
    }
    delete(UserDto) {
        return undefined;
    }
    async read(alias, password) {
        const params = {
            TableName: this.tableName,
            Key: {
                [this.alias]: alias
            },
        };
        const response = await this.client.send(new lib_dynamodb_1.GetCommand(params));
        const user = response.Item;
        if (user === undefined) {
            return [undefined, ""];
        }
        return [{
                alias: user[this.alias],
                firstName: user[this.firstName],
                lastName: user[this.lastName],
                imageUrl: user[this.imageUrl]
            }, user[this.password]];
    }
    update(UserDto) {
        return undefined;
    }
}
exports.UserDynamoDao = UserDynamoDao;
