"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserService = void 0;
const tweeter_shared_1 = require("tweeter-shared");
const buffer_1 = require("buffer");
const UserDynamoDao_1 = require("../../Dao/UserDao/UserDynamoDao");
const AuthDynamoDao_1 = require("../../Dao/AuthDao/AuthDynamoDao");
const crypto_1 = require("crypto");
const bcryptjs_1 = __importDefault(require("bcryptjs"));
class UserService {
    UserDao = new UserDynamoDao_1.UserDynamoDao();
    AuthDao = new AuthDynamoDao_1.AuthDynamoDao();
    generateUserDto = () => {
        const user = tweeter_shared_1.FakeData.instance.firstUser;
        if (user === null) {
            throw new Error("Invalid user");
        }
        return user.dto;
    };
    async login(alias, password) {
        let [userDto, hashedPassword] = await this.UserDao.read(alias, password);
        if (!bcryptjs_1.default.compareSync(password, hashedPassword) || !userDto) {
            throw new Error("[Bad Request] Invalid Username or Password1");
        }
        let authString = (0, crypto_1.randomBytes)(16).toString('hex');
        let authTokenDto = { token: authString, timestamp: Date.now() };
        await this.AuthDao.createAuth(authTokenDto, alias);
        return [userDto, authTokenDto];
    }
    ;
    async register(firstName, lastName, alias, password, userImageBytes, imageFileExtension) {
        // Not neded now, but will be needed when you make the request to the server in milestone 3
        const imageStringBase64 = buffer_1.Buffer.from(userImageBytes).toString("base64");
        let userDto = {
            firstName: firstName,
            lastName: lastName,
            alias: alias,
            imageUrl: imageStringBase64
        };
        const salt = bcryptjs_1.default.genSaltSync(10);
        const hashedPassword = bcryptjs_1.default.hashSync(password, salt);
        await this.UserDao.createUser(userDto, hashedPassword);
        let authString = (0, crypto_1.randomBytes)(16).toString('hex');
        let authTokenDto = { token: authString, timestamp: Date.now() };
        await this.AuthDao.createAuth(authTokenDto, alias);
        return [userDto, authTokenDto];
    }
    ;
    getUser = async (token, alias) => {
        let user = await tweeter_shared_1.FakeData.instance.findUserByAlias(alias);
        return user?.dto || null;
    };
    async logout(token) {
        // ause so we can see the logging out message. Delete when the call to the server is implemented.
        await new Promise((res) => setTimeout(res, 1000));
    }
    ;
}
exports.UserService = UserService;
