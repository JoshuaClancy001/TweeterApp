"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const UserDynamoDao_1 = require("./UserDynamoDao");
const AuthDynamoDao_1 = require("../AuthDao/AuthDynamoDao");
const UserDao = new UserDynamoDao_1.UserDynamoDao();
const AuthDao = new AuthDynamoDao_1.AuthDynamoDao();
let user = { firstName: "Josh", lastName: "Clancy", alias: "@jjc", imageUrl: "https://www.google.com" };
let auth = { token: "1234", timestamp: Date.now() };
async function createUser() {
    await UserDao.createUser(user, "password");
}
async function readUser(alias, password) {
    return await UserDao.read(alias, password);
}
async function createAuth() {
    await AuthDao.createAuth(auth, user.alias);
}
async function readAuth(alias, password) {
    return await AuthDao.readAuth(auth);
}
async function main() {
    await createUser();
    console.log(await readUser("@jjc", "wrong_password"));
    console.log(await readUser("@jjc", "password"));
    await createAuth();
    console.log(await readAuth("@jjc", "password"));
}
main().then(r => console.log("done"));
