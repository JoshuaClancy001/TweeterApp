"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FollowServiceBase = void 0;
const FollowService_1 = require("../../model/service/FollowService");
class FollowServiceBase {
    followService;
    constructor() {
        this.followService = new FollowService_1.FollowService();
    }
    async follow(token, userToFollow) {
        return await this.followAction(this.followService.follow(token, userToFollow));
    }
    async unfollow(token, userToUnfollow) {
        return await this.followAction(this.followService.unfollow(token, userToUnfollow));
    }
    async followAction(action) {
        const [followerCount, followeeCount] = await action;
        return { success: true, message: null, followerCount: followerCount, followeeCount: followeeCount };
    }
    async getFollowerCount(token, userAlias) {
        return await this.getCount(this.followService.getFollowerCount(token, userAlias));
    }
    async getFolloweeCount(token, userAlias) {
        return await this.getCount(this.followService.getFolloweeCount(token, userAlias));
    }
    async getCount(action) {
        const count = await action;
        return { success: true, message: null, count: count };
    }
    async getFollowers(token, userAlias, pageSize, lastItem) {
        return await this.getMore(this.followService.loadMoreFollowers(token, userAlias, pageSize, lastItem));
    }
    async getFollowees(token, userAlias, pageSize, lastItem) {
        return await this.getMore(this.followService.loadMoreFollowees(token, userAlias, pageSize, lastItem));
    }
    async getMore(action) {
        const [items, hasMore] = await action;
        return { success: true, message: null, items: items, hasMore: hasMore };
    }
    async getIsFollowerStatus(token, user, selectedUser) {
        const isFollower = await this.followService.getIsFollowerStatus(token, user, selectedUser);
        return { success: true, message: null, isFollower: isFollower };
    }
}
exports.FollowServiceBase = FollowServiceBase;
