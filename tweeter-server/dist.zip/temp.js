"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.temp = void 0;
const temp = () => {
    console.log('temp');
};
exports.temp = temp;
