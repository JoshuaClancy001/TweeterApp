"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const FollowServiceBase_1 = require("./FollowServiceBase");
const followService = new FollowServiceBase_1.FollowServiceBase();
const handler = async (request) => {
    return await followService.getIsFollowerStatus(request.token, request.user, request.selectedUser);
};
exports.handler = handler;
