"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserServiceBase = void 0;
const UserService_1 = require("../../model/service/UserService");
class UserServiceBase {
    userService;
    constructor() {
        this.userService = new UserService_1.UserService();
    }
    async authenticate(action) {
        const [user, token] = await action;
        return { success: true, message: null, user: user, authToken: token };
    }
    async login(alias, password) {
        return await this.authenticate(this.userService.login(alias, password));
    }
    async register(firstName, lastName, alias, password, userImageBytes, imageFileExtension) {
        return await this.authenticate(this.userService.register(firstName, lastName, alias, password, userImageBytes, imageFileExtension));
    }
    async getUser(token, alias) {
        const user = await this.userService.getUser(token, alias);
        return { success: true, message: null, user: user };
    }
    async logout(token) {
        await this.userService.logout(token);
        return { success: true, message: null };
    }
}
exports.UserServiceBase = UserServiceBase;
