"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const UserServiceBase_1 = require("./UserServiceBase");
const userBaseService = new UserServiceBase_1.UserServiceBase();
const handler = async (request) => {
    return await userBaseService.register(request.firstName, request.lastName, request.alias, request.password, request.userImageBytes, request.imageFileExtension);
};
exports.handler = handler;
