"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const FollowServiceBase_1 = require("./FollowServiceBase");
const followService = new FollowServiceBase_1.FollowServiceBase();
const handler = async (request) => {
    return await followService.getFollowees(request.token, request.userAlias, request.pageSize, request.lastItem);
};
exports.handler = handler;
