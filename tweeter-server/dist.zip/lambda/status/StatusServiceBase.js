"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.StatusServiceBase = void 0;
const StatusService_1 = require("../../model/service/StatusService");
class StatusServiceBase {
    statusService;
    constructor() {
        this.statusService = new StatusService_1.StatusService();
    }
    async postStatus(token, status) {
        await this.statusService.postStatus(token, status);
        return { success: true, message: null };
    }
    async getFeed(token, userAlias, pageSize, lastItem) {
        return await this.getItems(this.statusService.loadMoreFeedItems(token, userAlias, pageSize, lastItem));
    }
    async getStory(token, userAlias, pageSize, lastItem) {
        return await this.getItems(this.statusService.loadMoreStoryItems(token, userAlias, pageSize, lastItem));
    }
    async getItems(action) {
        const [items, hasMore] = await action;
        return { success: true, message: null, items: items, hasMore: hasMore };
    }
}
exports.StatusServiceBase = StatusServiceBase;
