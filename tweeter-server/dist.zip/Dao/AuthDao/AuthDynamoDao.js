"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthDynamoDao = void 0;
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
class AuthDynamoDao {
    tableName = "Authtokens";
    alias = "alias";
    authtoken = "authtoken";
    timestamp = "timestamp";
    expiration = "expiration";
    client = lib_dynamodb_1.DynamoDBDocumentClient.from(new client_dynamodb_1.DynamoDBClient());
    async createAuth(authtoken, alias) {
        const params = {
            TableName: this.tableName,
            Item: {
                [this.alias]: alias,
                [this.authtoken]: authtoken.token,
                [this.timestamp]: authtoken.timestamp,
                [this.expiration]: authtoken.timestamp + (5 * 60 * 1000)
            },
        };
        await this.client.send(new lib_dynamodb_1.PutCommand(params));
    }
    async deleteAuth(authtoken) {
        return undefined;
    }
    async readAuth(authtoken) {
        const params = {
            TableName: this.tableName,
            Key: {
                [this.authtoken]: authtoken.token
            },
        };
        const output = await this.client.send(new lib_dynamodb_1.GetCommand(params));
        return output.Item ? {
            token: output.Item[this.authtoken],
            timestamp: output.Item[this.timestamp]
        } : undefined;
    }
    async updateAuth(authtoken) {
        const params = {
            TableName: this.tableName,
            Key: {
                [this.authtoken]: authtoken.token
            },
            UpdateExpression: "SET timestamp = :timestamp",
            ExpressionAttributeValues: {
                ":timestamp": authtoken.timestamp
            },
        };
        await this.client.send(new lib_dynamodb_1.UpdateCommand(params));
    }
}
exports.AuthDynamoDao = AuthDynamoDao;
